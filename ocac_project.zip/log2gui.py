from tkinter import *
from tkinter import ttk,messagebox
from subprocess import call
# from PIL import ImageTk,Image

app = Tk()
app.title('Login')
app.state('zoomed')
app.configure(background='skyblue')

def check():
    username = e1.get()
    password = e2.get()

    if username == "":
        messagebox.showinfo("warning","First Field is empty")
    elif password == "":
        messagebox.showinfo("warning","Second Field is empty")
    else:
        if(username == 'ocac') and (password == 'ocac'):
            app.destroy()
            call(["python","miniproject2.py"])
        else:
            messagebox.showerror("Invalid credentials","username or password is wrong")
def back():
    app.destroy()
Label(app,text="Login To PowerPro Calculator",font='Helvetica',bg='yellow',fg='black').pack(fill='x')



username = StringVar()
password = StringVar()

lf1 = LabelFrame(bd='5',text='Login',bg='white',fg='red',font='impact 24 italic')
lf1.place(x=300,y=240,width=500,height=420)

Label(lf1,text='Username',font='ariel 16',bg='white',fg='black').pack()

e1 = Entry(lf1,bd='0.8',font='impack 13',textvariable = username)
e1.pack()


Label(lf1,text='Password',font='ariel 16',bg='white',fg='black').pack()

e2 = Entry(lf1,bd='0.8',font='impack 13',show='*',textvariable=password)
e2.pack()


login = Button(lf1,text='Login',font='ariel 15 bold',bg='red',fg='white',bd='2',cursor='hand2',command=check)
login.place(x=70,y=200,width=150)

cancel = Button(lf1,text='Exit',font='ariel 15 bold',bg='red',fg='white',bd='2',cursor='hand2',command=back)
cancel.place(x=270,y=200,width=150)

app.mainloop()