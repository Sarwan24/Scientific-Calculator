import tkinter as tk
from tkinter import ttk
from tkinter import messagebox


# Create the main application window
app = tk.Tk()
app.title("Calculator")


# Function to calculate income and expenses
def calculate_balance():
    income = sum([float(income_entry.get()) for income_entry in income_entries])
    expenses = sum([float(expense_entry.get()) for expense_entry in expense_entries])

    #if(income== "" or expenses== ""):
       # messagebox.showinfo("","Blank not allowed")
    #elif (income or expenses < 0):
    #    messagebox.showinfo("negative value not allow")
    #else:
      #  messagebox.showinfo("ok done")
    balance = income - expenses
    balance_label.config(text=f"Balance: {balance}")

# Function to perform converter calculations
def perform_conversion():
    input_value = float(conversion_entry.get())
    selected_conversion = conversion_type.get()
    
    if selected_conversion == "Degree to Celsius":
        result = (input_value - 32) * 5/9
    elif selected_conversion == "Meter to Km":
        result = input_value / 1000
    elif selected_conversion == "Km to Meter":
        result = input_value * 1000
    elif selected_conversion == "Centimeter to Meter":
        result = input_value / 100
    elif selected_conversion == "Meter to Centimeter":
        result = input_value * 100
    
    conversion_result.config(text=f"Result: {result}")

# Function to calculate attendance percentage

def calculate_percentage():
    present_days = sum(int(day.get()) for day in day_entries)
    total_days = len(day_entries)
    percentage = (present_days / total_days) * 100
    absent_day = total_days - present_days
    result_label.config(text=f" Present day Percentage: {percentage}% \n present day :{present_days} \n absent day: {absent_day}")

# Function to calculate electricity cost
def calculate_electricity_cost():
    unit = float(unit_entry.get())
    rate_per_unit = float(rate_entry.get())
    total_cost = unit * rate_per_unit
    electricity_result.config(text=f"Total Cost: {total_cost}")

# Create tabs for different calculations
tab_control = ttk.Notebook(app)
tab1 = ttk.Frame(tab_control)
tab2 = ttk.Frame(tab_control)
tab3 = ttk.Frame(tab_control)
tab4 = ttk.Frame(tab_control)

tab_control.add(tab1, text="Income/Expense")
tab_control.add(tab2, text="Converter")
tab_control.add(tab3, text="Attendance")
tab_control.add(tab4, text="Electricity")
tab_control.pack(expand=1, fill="both")

# Income/Expense Calculation
income_entries = []
expense_entries = []

num=tk.Label(tab1,text="Income",font=("Helvetica", 20))
num.grid(row =0, column =1)

num=tk.Label(tab1,text="Expense",font=("Helvetica", 20))
num.grid(row =0, column =2)

for i in range(2,9):
    
    
    tk.Label(tab1, text=f"Day {i-1}",font=("Helvetica" ,15 )).grid(row=i, column=0)
    
    income_entry = tk.Entry(tab1)
    income_entry.grid(row=i, column=1)
    income_entries.append(income_entry)
    expense_entry = tk.Entry(tab1)
    expense_entry.grid(row=i, column=2)
    expense_entries.append(expense_entry)

calculate_button = tk.Button(tab1, text="Calculate", command=calculate_balance,font=("Helvetica", 15))
calculate_button.grid(row=9, column=0, columnspan=3)

balance_label = tk.Label(tab1, text="Balance: ")
balance_label.grid(row=10, column=0, columnspan=3)


# Converter Calculation
conversion_label = tk.Label(tab2, text="Enter Value:")
conversion_label.pack()
conversion_entry = tk.Entry(tab2)
conversion_entry.pack()

conversion_type = ttk.Combobox(tab2, values=["Degree to Celsius", "Meter to Km", "Km to Meter", "Centimeter to Meter", "Meter to Centimeter"])
conversion_type.pack()
conversion_type.set("Degree to Celsius")

convert_button = tk.Button(tab2, text="Convert", command=perform_conversion)
convert_button.pack()

conversion_result = tk.Label(tab2, text="")
conversion_result.pack()

# Attendance Calculation


day_entries = []

num=tk.Label(tab3,text="Present / Absent",font=("Helvetica",20))
num.grid(row =0, column =1)

for i in range(2,17):
    day_label = tk.Label(tab3, text=f"Day {i-1}:",font=("Helvetica", 15))
    day_label.grid(row=i, column=0)
    day_entry = tk.Entry(tab3)
    day_entry.grid(row=i, column=1)
    day_entries.append(day_entry)

calculate_button = tk.Button(tab3, text="Calculate", command=calculate_percentage,font=("Helvetica", 20))
calculate_button.grid(row=17, column=0, columnspan=2)

result_label = tk.Label(tab3,text="answer is:")
result_label.grid(row=18, column=0, columnspan=2)

# Electricity Calculation
unit_label = tk.Label(tab4, text="Units Consumed:")
unit_label.pack()
unit_entry = tk.Entry(tab4)
unit_entry.pack()

rate_label = tk.Label(tab4, text="Rate per Unit:")
rate_label.pack()
rate_entry = tk.Entry(tab4)
rate_entry.pack()

electricity_button = tk.Button(tab4, text="Calculate", command=calculate_electricity_cost)
electricity_button.pack()

electricity_result = tk.Label(tab4, text="")
electricity_result.pack()

# Start the main loop
app.mainloop()